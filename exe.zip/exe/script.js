// Definir variáveis globais
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var aliens = [];

var imagem = new Image();
imagem.src = "alien.png";

var imagem2 = new Image();
imagem2.src = "nave.png";

var player = {
  x: 275,
  y: canvas.height - 50,
  width: 35,
  height: 35,
  speed: 5
};
var bullets = [];
var score = 0;
var n = 0;

// Criar os aliens
for (var i = 0; i < 5; i++) {
  for (var j = 0; j < 10; j++) {
    var alien = {
      x: j * 40 + 20,
      y: i * 40 + 20,
      width: 30,
      height: 30,
      speed: 1,
      direction: 1
    };
    aliens.push(alien);
  }
}

// Desenhar os aliens
function drawAliens() {
  for (var i = 0; i < aliens.length; i++) {
    ctx.drawImage(imagem, aliens[i].x, aliens[i].y, aliens[i].width, aliens[i].height);
  }
}

// Desenhar o jogador
function drawPlayer() {
  ctx.drawImage(imagem2, player.x, player.y, player.width, player.height);
}

// Mover o jogador
function movePlayer() {
  if (keys[37]) { // Esquerda
    player.x -= player.speed;
  }
  if (keys[39]) { // Direita
    player.x += player.speed;
  }
  if (keys[32]) { // Espaço (Atirar)
    shootBullet();
  }
}

// Mover o alien
function moveAlien() {
    window.setInterval(function(){
      for (var i = 0; i < 5; i++) {
        for (var j = 0; j < 10; j++) {
          alien = {
            x: j * (40+speed) + 20,
            y: i * 40 + 20,
            speed: 1,
          };
         
        } 
      }speed++;
    },1000);
  }


// Desenhar as balas
function drawBullets() {
  for (var i = 0; i < bullets.length; i++) {
    ctx.fillStyle = "red";
    ctx.fillRect(bullets[i].x, bullets[i].y, bullets[i].width, bullets[i].height);
  }
}

// Mover as balas
function moveBullets() {
  for (var i = 0; i < bullets.length; i++) {
    bullets[i].y -= 10;
    if (bullets[i].y < 0) {
      bullets.splice(i, 1);
      i--;
    }
  }
}

// Atirar uma bala
function shootBullet() {
  var bullet = {
    x: player.x + player.width / 2 - 2.5,
    y: player.y - 10,
    width: 5,
    height: 10,
    speed: 10
  };
  bullets.push(bullet);
}

// Colisão entre balas e aliens
function checkBulletAlienCollision() {
  for (var i = 0; i < bullets.length; i++) {
    for (var j = 0; j < aliens.length; j++) {
      if (bullets[i].x < aliens[j].x + aliens[j].width &&
        bullets[i].x + bullets[i].width > aliens[j].x &&
        bullets[i].y < aliens[j].y + aliens[j].height &&
        bullets[i].y + bullets[i].height > aliens[j].y) {
        bullets.splice(i, 1);
        i--;
        aliens.splice(j, 1);
        score += 10;
        if(score == 500){
          setTimeout(alert("Venceu!"), 2000);
        }
        break;
      }
    }
  }
}

// Colisão entre jogador e aliens
function checkPlayerAlienCollision() {
  for (var i = 0; i < aliens.length; i++) {
    if (player.x < aliens[i].x + aliens[i].width &&
      player.x + player.width > aliens[i].x &&
      player.y < aliens[i].y + aliens[i].height &&
      player.y + player.height > aliens[i].y) {
      alert("Você perdeu! Sua pontuação foi: " + score);
      document.location.reload();
      clearInterval(interval);
      break;
    }
  }
}

// Desenhar a pontuação
function drawScore() {
  ctx.fillStyle = "black";
  ctx.font = "20px Arial";
  ctx.fillText("Pontuação: " + score, 10, 30);
}

// Loop principal do jogo
function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawAliens();
  drawPlayer();
  movePlayer();
  moveAlien();
  drawBullets();
  moveBullets();
  checkBulletAlienCollision();
  checkPlayerAlienCollision();
  drawScore();
}

// Iniciar o loop do jogo
var interval = setInterval(gameLoop, 20);

// Eventos de teclado
var keys = [];
document.addEventListener("keydown", function(event) {
  keys[event.keyCode] = true;
});
document.addEventListener("keyup", function(event) {
  keys[event.keyCode] = false;
});